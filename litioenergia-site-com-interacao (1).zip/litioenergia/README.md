# litioenergia.com.br

Site estático, arquivo único (index.html), sem build.

Publicar no GitHub Pages: envie index.html, CNAME e .nojekyll; em Settings > Pages, branch main, pasta /.
DNS no Registro.br: quatro registros A em @ (185.199.108.153 a 185.199.111.153) e CNAME em www.

Antes de publicar: confirme os dados de produção e investimento nas fontes; o formulário abre o e-mail (sem servidor).
Site criado por Guilherme Morais Nascimento (guilhermenascimento867@gmail.com).
